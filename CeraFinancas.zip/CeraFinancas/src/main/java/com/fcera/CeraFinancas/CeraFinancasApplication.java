package com.fcera.CeraFinancas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CeraFinancasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CeraFinancasApplication.class, args);
	}

}

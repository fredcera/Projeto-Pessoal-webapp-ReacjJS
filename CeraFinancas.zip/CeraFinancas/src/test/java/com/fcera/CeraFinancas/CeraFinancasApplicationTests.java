package com.fcera.CeraFinancas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CeraFinancasApplicationTests {

	@Test
	void contextLoads() {
	}

}
